package com.tmy.config;

public class OAuthTypes {

    public static final String WEIXIN = "weixin";

}
